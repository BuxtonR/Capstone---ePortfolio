// Enhanced Encryption App
// Developed by Buxton McCaslin | CS-405 Enhancement for CS-499
// This refactored version improves modularity, error handling, and clarity

#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <string>
#include <ctime>
#include <filesystem>
#include <stdexcept>
#include <cassert>

using namespace std;
namespace fs = std::filesystem;

// This class handles all file input/output tasks
class FileHandler {
public:
    // Reads the entire content of a file and returns it as a string
    static string readFile(const string& filename) {
        ifstream input(filename);
        if (!input) {
            throw runtime_error("Unable to open file: " + filename);
        }
        stringstream buffer;
        buffer << input.rdbuf();
        return buffer.str();
    }

    // Saves encrypted/decrypted output into a file along with metadata
    static void saveDataFile(const string& filename, const string& studentName, const string& key, const string& data) {
        ofstream output(filename);
        if (!output) {
            throw runtime_error("Unable to open file for writing: " + filename);
        }

        // Capture the current date for the header
        time_t now = time(nullptr);
        tm local_tm;
#ifdef _WIN32
        localtime_s(&local_tm, &now);
#else
        localtime_r(&now, &local_tm);
#endif

        // Write metadata and content to the file
        output << studentName << "\n";
        output << put_time(&local_tm, "%Y-%m-%d") << "\n";
        output << key << "\n";
        output << data << endl;
    }
};

// This class contains methods for encryption, decryption, and string parsing
class Encryptor {
public:
    // XOR-based symmetric encryption/decryption function
    static string encryptDecrypt(const string& source, const string& key) {
        assert(!key.empty());
        assert(!source.empty());

        string output = source;
        for (size_t i = 0; i < source.length(); ++i) {
            output[i] = source[i] ^ key[i % key.length()];
        }

        assert(output.length() == source.length());
        return output;
    }

    // Pulls the student's name from the first line of the input file
    static string getStudentName(const string& data) {
        size_t pos = data.find('\n');
        return (pos != string::npos) ? data.substr(0, pos) : "Unknown";
    }
};

// The main function that ties everything together
int main() {
    cout << "Enhanced Encryption/Decryption Program by Buxton McCaslin" << endl;

    // Show working directory (helps with debugging)
    cout << "Current directory: " << fs::current_path() << endl;

    // Define file names and password key
    const string inputFile = "inputdatafile.txt";
    const string encryptedFile = "encrypteddatafile.txt";
    const string decryptedFile = "decrypteddatafile.txt";
    const string key = "password";

    try {

        // Debug line: Print the absolute path
        cout << "Attempting to read: " << fs::absolute(inputFile) << endl;

        // Step 1: Read source data from file
        string sourceData = FileHandler::readFile(inputFile);

        // Step 2: Get student name from first line of file
        string studentName = Encryptor::getStudentName(sourceData);

        // Step 3: Encrypt the full file content
        string encrypted = Encryptor::encryptDecrypt(sourceData, key);

        // Step 4: Decrypt the result back to original
        string decrypted = Encryptor::encryptDecrypt(encrypted, key);

        // Step 5: Save both outputs to their respective files
        FileHandler::saveDataFile(encryptedFile, studentName, key, encrypted);
        cout << "Encrypted file saved to: " << encryptedFile << endl;

        FileHandler::saveDataFile(decryptedFile, studentName, key, decrypted);
        cout << "Decrypted file saved to: " << decryptedFile << endl;

        cout << "Program completed successfully." << endl;
    }
    catch (const exception& e) {
        cerr << "Error: " << e.what() << endl;
        return 1;
    }

    return 0;
}
