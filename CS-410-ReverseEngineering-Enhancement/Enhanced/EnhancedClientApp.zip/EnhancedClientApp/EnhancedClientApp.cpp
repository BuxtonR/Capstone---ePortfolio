// Project: EnhancedClientApp
// Author: Buxton McCaslin
// Course : CS - 499 : Computer Science Capstone
// 
// Description:
// A modular C++ console app for managing users with permission levels.
// Demonstrates strong use of classes, vectors, input validation, and clean structure.

#include <iostream>
#include <vector>
#include <string>
#include <limits>

using namespace std;

// User class stores basic client data: name and permission level
class User {
private:
    string name;
    int permissionLevel;

public:
    User(const string& name, int level) : name(name), permissionLevel(level) {}

    string getName() const { return name; }
    int getPermissionLevel() const { return permissionLevel; }

    void display() const {
        cout << "Name: " << name << ", Permission Level: " << permissionLevel << endl;
    }
};

// ClientManager handles all operations related to managing users
class ClientManager {
private:
    vector<User> users;

public:
    // Adds a new user to the vector
    void addUser(const string& name, int level) {
        users.emplace_back(name, level);
        cout << "User added successfully.\n";
    }

    // Displays all users in the system
    void showUsers() const {
        if (users.empty()) {
            cout << "No users found.\n";
            return;
        }

        cout << "\n=== Registered Users ===\n";
        for (const auto& user : users) {
            user.display();
        }
        cout << "========================\n";
    }
};

// Displays menu and gets validated user choice
int displayMenu() {
    cout << "\n--- Client Manager Menu ---\n";
    cout << "1. Add User\n";
    cout << "2. Show Users\n";
    cout << "3. Exit\n";
    cout << "Enter your choice: ";

    int choice;
    while (!(cin >> choice) || choice < 1 || choice > 3) {
        cout << "Invalid input. Please enter a number between 1 and 3: ";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }
    cin.ignore(); // discard leftover newline
    return choice;
}

// Handles the input for adding a new user
void handleAddUser(ClientManager& manager) {
    string name;
    int level;

    cout << "Enter user name: ";
    getline(cin, name);

    cout << "Enter permission level (1 = User, 2 = Admin): ";
    while (!(cin >> level) || (level != 1 && level != 2)) {
        cout << "Invalid input. Enter 1 for User or 2 for Admin: ";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }
    cin.ignore(); // discard newline after number input

    manager.addUser(name, level);
}

int main() {
    ClientManager manager;
    bool running = true;

    while (running) {
        int choice = displayMenu();

        switch (choice) {
        case 1:
            handleAddUser(manager);
            break;
        case 2:
            manager.showUsers();
            break;
        case 3:
            running = false;
            cout << "Exiting program. Goodbye!\n";
            break;
        }
    }

    return 0;
}
