BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS "Customers" (
	"CustomerID"	INTEGER,
	"FirstName"	TEXT NOT NULL,
	"LastName"	TEXT NOT NULL,
	"Email"	TEXT NOT NULL UNIQUE,
	PRIMARY KEY("CustomerID" AUTOINCREMENT)
);
CREATE TABLE IF NOT EXISTS "Products" (
	"ProductID"	INTEGER,
	"ProductName"	TEXT NOT NULL,
	"Category"	TEXT NOT NULL,
	PRIMARY KEY("ProductID" AUTOINCREMENT)
);
CREATE TABLE IF NOT EXISTS "Returns" (
	"ReturnID"	INTEGER,
	"CustomerID"	INTEGER,
	"ProductID"	INTEGER,
	"ReturnDate"	DATE,
	"Reason"	TEXT,
	PRIMARY KEY("ReturnID" AUTOINCREMENT),
	FOREIGN KEY("CustomerID") REFERENCES "Customers"("CustomerID"),
	FOREIGN KEY("ProductID") REFERENCES "Products"("ProductID")
);
INSERT INTO "Customers" VALUES (1,'John','Doe','john.doe@example.com');
INSERT INTO "Customers" VALUES (2,'Jane','Smith','jane.smith@example.com');
INSERT INTO "Products" VALUES (1,'Basic Switch 10/100/1000 BaseT','Networking');
INSERT INTO "Products" VALUES (2,'Advanced Switch 10GigE Copper','Networking');
INSERT INTO "Returns" VALUES (1,1,1,'2025-05-01','Defective');
INSERT INTO "Returns" VALUES (2,2,2,'2025-05-02','Incorrect item');
CREATE INDEX IF NOT EXISTS "idx_customer_id" ON "Returns" (
	"CustomerID"
);
CREATE INDEX IF NOT EXISTS "idx_product_id" ON "Returns" (
	"ProductID"
);
CREATE INDEX IF NOT EXISTS "idx_returns_customerid" ON "Returns" (
	"CustomerID"
);
COMMIT;
